package Entities;

public class clsAdmin extends clsPersonas{
    
    private String User;
    private String Password;

    public clsAdmin() {
        this.User = "";
        this.Password = "";
    }
    
    public clsAdmin(String User, String Password) {
        this.User = User;
        this.Password = Password;
    }

    public clsAdmin(String User, String Password, String IDpersonas, String NombrePer, String ApellidoPer, String FechaNacPer) {
        super(IDpersonas, NombrePer, ApellidoPer, FechaNacPer);
        this.User = User;
        this.Password = Password;
    }

    public String getUser() {
        return User;
    }

    public String getPassword() {
        return Password;
    }

    public void setUser(String User) {
        this.User = User;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    

    
}
