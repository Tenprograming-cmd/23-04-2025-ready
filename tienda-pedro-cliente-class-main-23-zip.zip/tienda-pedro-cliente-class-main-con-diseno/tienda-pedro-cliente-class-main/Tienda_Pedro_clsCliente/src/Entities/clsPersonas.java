package Entities;

public abstract class clsPersonas {

    // variables globales
    // principio 1 de encapsulamiento (definir su nivel de acceso)
    private String IDpersonas;
    private String NombrePer;
    private String ApellidoPer;
    private String FechaNacPer;
    
    
    // metodo constructor
    // principio de polimorfismo (toma de decisiones basado en su contenido)
    public clsPersonas(){
        this.IDpersonas = "";
        this.NombrePer = "";
        this.ApellidoPer = "";
        this.FechaNacPer = "";
        
    
    }

    public clsPersonas(String IDpersonas, String NombrePer, String ApellidoPer, String FechaNacPer){
        this.IDpersonas = IDpersonas;
        this.NombrePer = NombrePer;
        this.ApellidoPer = ApellidoPer;
        this.FechaNacPer = FechaNacPer;
    
    }
    
    // getter
    // Metodos para obtener los valores que tienen las variables
    public String getIDpersonas(){
        return this.IDpersonas;
    }
    
    public String getNombrePer(){
        return this.NombrePer;
    }
    
    public String getApellidoPer(){
        return this.ApellidoPer;
    }
    
    public String getFechaNacPer(){
        return this.FechaNacPer;
    }
    
    // setter
    // metodos que permiten la modificacion de los valores de las variables
    public void setIDpersonas(String IDpersonas){
        this.IDpersonas = IDpersonas;
    }
    
    public void setNombrePer(String NombrePer){
        this.NombrePer = NombrePer;
    }
    
    public void setApellidoPer(String ApellidoPer){
        this.ApellidoPer = ApellidoPer;
    }
    
    public void setFechaNacPer(String FechaNacPer){
        this.FechaNacPer = FechaNacPer;
    }

     
}