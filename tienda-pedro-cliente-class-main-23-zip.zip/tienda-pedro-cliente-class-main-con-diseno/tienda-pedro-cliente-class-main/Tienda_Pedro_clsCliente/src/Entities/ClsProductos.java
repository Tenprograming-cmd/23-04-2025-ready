
package Entities;

public class ClsProductos {
    
    private int IDproductos;
    private String NombreProductos;
    private String DescripProd;
    private int StockProd;

    public ClsProductos(int IDproductos, String NombreProductos, String DescripProd, int StockProd) {
        this.IDproductos = IDproductos;
        this.NombreProductos = NombreProductos;
        this.DescripProd = DescripProd;
        this.StockProd = StockProd;
    }

    public int getIDproductos() {
        return IDproductos;
    }

    public void setIDproductos(int IDproductos) {
        this.IDproductos = IDproductos;
    }

    public String getNombreProductos() {
        return NombreProductos;
    }

    public void setNombreProductos(String NombreProductos) {
        this.NombreProductos = NombreProductos;
    }

    public String getDescripProd() {
        return DescripProd;
    }

    public void setDescripProd(String DescripProd) {
        this.DescripProd = DescripProd;
    }

    public int getStockProd() {
        return StockProd;
    }

    public void setStockProd(int StockProd) {
        this.StockProd = StockProd;
    }

    @Override
    public String toString() {
        return "ClsProductos{" + "IDproductos=" + IDproductos + ", NombreProductos=" + NombreProductos + ", DescripProd=" + DescripProd + ", StockProd=" + StockProd + '}';
    }
    
    
}
