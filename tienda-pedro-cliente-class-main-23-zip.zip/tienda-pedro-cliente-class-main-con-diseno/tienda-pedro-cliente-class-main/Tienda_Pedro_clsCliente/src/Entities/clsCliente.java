package Entities;

public class clsCliente extends clsPersonas {
    
    private String Correo;
    private String Telefono;
    private String Direccion;
    private String Genero;

    // Constructor por defecto
    public clsCliente() {
        super();
        this.Correo = "";
        this.Telefono = "";
        this.Direccion = "";
        this.Genero = "";
    }

    // Constructor con todos los campos
    public clsCliente(String IDpersonas, String NombrePer, String ApellidoPer, String FechaNacPer,
                      String Correo, String Telefono, String Direccion, String Genero) {
        super(IDpersonas, NombrePer, ApellidoPer, FechaNacPer);
        this.Correo = Correo;
        this.Telefono = Telefono;
        this.Direccion = Direccion;
        this.Genero = Genero;
    }

    // Getters
    public String getCorreo() {
        return Correo;
    }

    public String getTelefono() {
        return Telefono;
    }

    public String getDireccion() {
        return Direccion;
    }

    public String getGenero() {
        return Genero;
    }

    // Setters
    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    @Override
    public String toString() {
        return "clsCliente{" + 
                "ID=" + getIDpersonas() +
                ", Nombre=" + getNombrePer() +
                ", Apellido=" + getApellidoPer() +
                ", FechaNacimiento=" + getFechaNacPer() +
                ", Correo=" + Correo + 
                ", Telefono=" + Telefono + 
                ", Direccion=" + Direccion + 
                ", Genero=" + Genero + 
                '}';
    }
}
