package Connection;

import java.sql.*;
import javax.swing.JOptionPane;

public class clsConnectionDB {

    // Declaración de variables globales
    Connection CN; // "Connection" es un tipo de dato de Java y está asociada con el import de SQL

    public clsConnectionDB(){}

    public Connection Conectar(){
        try {
            String url, user, password;

            url = "jdbc:mysql://localhost:3306/db_tienda_pedro";
            user = "root";
            password = "1234";

            Class.forName("com.mysql.cj.jdbc.Driver"); // Esto instala un driver jdbc
            CN = DriverManager.getConnection(url, user, password); // Conexión con los datos anteriores

            if (CN != null){
                JOptionPane.showConfirmDialog(null, "Conexión exitosa");
            }

        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error en la base de datos: " + e.getMessage());
        }

        return CN;
    }
    
    public Connection Desconectar(){
        
        CN = null;
        JOptionPane.showMessageDialog(null, "Desconexion exitosa");
        return CN;
    }
}
